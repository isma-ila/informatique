"""
"""


class LiveController:
    def __init__(self, liveModel, liveView):
        self.model = liveModel
        self.view = liveView
        self.view.get_canvas().bind("<Button-1>", self.view.click_gauche)
        self.view.get_canvas().bind("<Button-3>", self.view.click_droit)
        self.view.get_canvas().focus_set()

        self.view.play()
        self.view.mainloop()
