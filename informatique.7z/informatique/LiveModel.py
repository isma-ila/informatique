# LiveModel.py
import copy

"""
"""


class LiveModel:
    def __init__(self):
        self.height = 200
        self.width = 200
        self.c = 10
        self.dico_case = {}
        self.dico_etat = {}
        self.flag = 0
        self.vitesse = 50

    def get_height(self):
        return self.height

    def set_vitesse(self, vitesse):
        self.vitesse = vitesse

    def set_flag(self, value):
        self.flag = value

    def get_width(self):
        return self.width

    def get_c(self):
        return self.c

    def get_dico_case(self):
        return self.dico_case

    def get_dico_etat(self):
        return self.dico_etat

    def get_flag(self):
        return self.flag

    def get_vitesse(self):
        return self.vitesse

    def initialisation_cellules(self):
        i = 0
        while i != self.get_width() / self.get_c():
            j = 0
            while j != self.get_height() / self.get_c():
                x = i * self.get_c()
                y = j * self.get_c()
                self.get_dico_case()[x, y] = 0
                j += 1
            i += 1

    def set_dico_etat(self, dico):
        self.dico_etat = copy.deepcopy(dico)
